number=[1,2,15,4,5,9,5,6,5]
puts "Number after Sort"
puts number.sort