array = [1, 2, 3, 2, 4, 3, 5, 6, 5, 7, 8, 8]
groups = array.group_by(&:itself)
counts = groups.map { |value, group| [value, group.count] }
duplicates = counts.select { |value, count| count > 1 }
duplicates.each do |value, count|
  puts "#{value} appears #{count} times"
end