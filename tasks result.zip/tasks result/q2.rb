def second_largest(lar)
  lar.max(2).min
end

puts "The second_largest number is #{second_largest([5, 8, 2, 9, 1])}"


def second_Smallest(small)
  small.min(2).max
end
puts "The second_Smallest numder is #{second_Smallest([1,2,4,34])}"