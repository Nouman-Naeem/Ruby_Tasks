def largest(lar)
  lar.max(1).min
end

puts "The largest number is #{largest([5, 8, 2, 9, 1])}"
